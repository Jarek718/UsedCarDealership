import main.*;
import org.junit.jupiter.api.*;

public class CarTests {
    @Test
    public void doesReturnPrice(){
        ConcreteCar subject = new ConcreteCar("Ford", "Focus", (short) 2020, 25000);
        PriceObserver observer = new PriceObserver();
        subject.addObserver(observer);
        subject.notifyObserversPrice(23000);
        Assertions.assertEquals(23000, observer.getPrice());
    }
    @Test
    public void doesReturnYear(){
        ConcreteCar subject = new ConcreteCar("Ford", "Focus", (short) 2020, 25000);
        YearObserver observer = new YearObserver();
        subject.addObserver(observer);
        subject.notifyObserversYear((short) 2021);
        Assertions.assertEquals(2021, observer.getYear());

    }
}
