package main;

public class YearObserver implements Observer{
    private short Year;
    @Override
    public void update(Object Year) {
        this.setYear((short) Year);
    }
    public double getYear() {
        return this.Year;
    }
    public void setYear(short year)
    {
        this.Year = year;
    }
}
