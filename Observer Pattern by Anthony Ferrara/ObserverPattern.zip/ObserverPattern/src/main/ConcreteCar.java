package main;
import java.util.List;
import java.util.ArrayList;

public class ConcreteCar implements Car
{
    private String Make;
    private String Model;
    private short Year;
    private double Price;
    private List<Observer> observers = new ArrayList<>();


    public ConcreteCar(String make, String model, short year, double price)
    {
        Make = make;
        Model = model;
        Year = year;
        Price = price;
    }

    @Override
    public String getMake()
    {
        return this.Make;
    }

    @Override
    public void setMake(String make)
    {
        this.Make = make;

    }

    @Override
    public String getModel()
    {
        return this.Model;
    }

    @Override
    public void setModel(String model)
    {
        this.Model = model;
    }

    @Override
    public short getYear()
    {
        return this.Year;
    }

    @Override
    public void setYear(short year)
    {
        this.Year = year;
    }

    @Override
    public double getPrice()
    {
        return this.Price;
    }

    @Override
    public void setPrice(double price)
    {
        this.Price = price;
    }

    public String toString()
    {
        return "Make: "+Make+"\nModel: "+Model+"\nYear: "+Year+"\nPrice: "+Price;
    }
    public void addObserver(Observer observer) {
        this.observers.add(observer);
    }

    public void removeObserver(Observer observer) {
        this.observers.remove(observer);
    }

    public void notifyObserversPrice(double price) {
        this.Price = price;
        for (Observer observer : this.observers) {
            observer.update(this.Price);
        }
    }
    public void notifyObserversYear(short year) {
        this.Year = year;
        for (Observer observer : this.observers) {
             observer.update(this.Year);
            }
        }
    }