package main;

public class PriceObserver implements Observer{
    private double Price;
    @Override
    public void update(Object Price) {
        this.setPrice((Double) Price);
    }
    public double getPrice() {
        return this.Price;
    }
    public void setPrice(double price)
    {
        this.Price = price;
    }
}
