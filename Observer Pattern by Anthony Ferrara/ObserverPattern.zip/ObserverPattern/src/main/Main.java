package main;


public class Main {
    public static void driver() {
        ConcreteCar subject = new ConcreteCar("Hyundai", "Elantra Sport", (short) 2001, 9000);
        YearObserver observer = new YearObserver();
        PriceObserver priceObserver = new PriceObserver();
        subject.addObserver(observer);
        subject.notifyObserversYear((short) 1999);
        System.out.println(observer.getYear());
        subject.removeObserver(observer);
        subject.addObserver(priceObserver);
        subject.notifyObserversPrice(75000);
        System.out.println(priceObserver.getPrice());

    }
    public static void main(String[] args) {
        driver();
    }


}